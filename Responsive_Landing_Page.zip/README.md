# 🌐 Responsive Landing Page

A modern and responsive landing page built using HTML, CSS, and JavaScript with a fixed navigation bar and scroll-based effects.

## Features
- Responsive design
- Fixed navbar
- Gradient UI
- Scroll-based navbar effect

## Tech Stack
- HTML
- CSS
- JavaScript

## Author
Shivaprasad Chinthoju
